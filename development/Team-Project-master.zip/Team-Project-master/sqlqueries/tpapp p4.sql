

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `is_admin`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Lewis Mann', 'eaglenebula286@gmail.com', NULL, '$2y$10$vtUj2xWobMzdy16CQSx.NurWWb8nAzbTiYV37T8/gpUeDJMmMPwo.', 0, NULL, '2022-04-26 18:34:29', '2022-04-26 18:34:29');

INSERT INTO `user_products_mappings` (`id`, `user_id`, `product_id`, `type`) VALUES
(11, 1, 397, 'games'),
(12, 1, 475, 'games'),
(13, 1, 81, 'games'),
(14, 1, 476, 'games'),
(15, 1, 270, 'games'),
(16, 1, 480, 'games'),
(18, 1, 230, 'games'),
(19, 1, 364, 'games'),
(20, 1, 481, 'games'),
(21, 1, 501, 'games'),
(22, 1, 85, 'games'),
(23, 1, 337, 'games'),
(24, 1, 7068, 'games'),
(25, 1, 99, 'games'),
(26, 1, 6899, 'games'),
(27, 1, 2532, 'games'),
(28, 1, 1, 'games'),
(29, 1, 286, 'games');
