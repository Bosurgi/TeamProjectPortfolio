<div class="bg-dark col text-center text-white m-2">
    <div class="my-3 py-3">
        <h2 class="display-5 text-light">Another headline</h2>
        <p class="lead text-light">And an even wittier subheading.</p>
    </div>
    <!--<div class="bg-dark shadow-sm mx-auto" style="width: 80%; height: 300px; border-radius: 21px 21px 0 0;"></div>-->
</div> 