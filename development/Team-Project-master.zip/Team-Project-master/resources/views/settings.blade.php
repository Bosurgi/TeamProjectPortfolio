<x-app>
	<main class="container">
		<h1>settings</h1>
	</main>
</x-app>
