<x-app>
    email sent
</x-app>