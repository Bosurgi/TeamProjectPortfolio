<x-app>
	<main class="container">
		<h1>profile</h1>
	</main>
</x-app>
