
try {
    require('jquery');
} catch (e) {}
